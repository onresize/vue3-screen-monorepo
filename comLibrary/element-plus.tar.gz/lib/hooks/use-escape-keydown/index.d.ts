export declare const useEscapeKeydown: (handler: (e: KeyboardEvent) => void) => void;
