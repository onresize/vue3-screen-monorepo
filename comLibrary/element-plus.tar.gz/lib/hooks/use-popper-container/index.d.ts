export declare const usePopperContainerId: () => {
    id: import("vue").ComputedRef<string>;
    selector: import("vue").ComputedRef<string>;
};
export declare const usePopperContainer: () => {
    id: import("vue").ComputedRef<string>;
    selector: import("vue").ComputedRef<string>;
};
