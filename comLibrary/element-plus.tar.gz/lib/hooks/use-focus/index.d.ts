import type { Ref } from 'vue';
export declare const useFocus: (el: Ref<{
    focus: () => void;
} | null>) => {
    focus: () => void;
};
