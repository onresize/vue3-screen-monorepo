export declare const version = "0.0.0-dev.1";
