export * from 'element-plus/es/locale';
