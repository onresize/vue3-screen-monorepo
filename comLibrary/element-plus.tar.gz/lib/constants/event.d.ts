export declare const UPDATE_MODEL_EVENT = "update:modelValue";
export declare const CHANGE_EVENT = "change";
export declare const INPUT_EVENT = "input";
