export declare const INSTALLED_KEY: unique symbol;
