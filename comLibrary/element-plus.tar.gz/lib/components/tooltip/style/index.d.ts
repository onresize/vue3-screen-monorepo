import 'element-plus/es/components/base/style';
import 'element-plus/theme-chalk/src/tooltip.scss';
import 'element-plus/es/components/popper/style';
