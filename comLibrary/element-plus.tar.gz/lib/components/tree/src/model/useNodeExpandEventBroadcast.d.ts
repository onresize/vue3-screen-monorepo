import type Node from '../model/node';
export declare function useNodeExpandEventBroadcast(props: any): {
    broadcastExpanded: (node: Node) => void;
};
