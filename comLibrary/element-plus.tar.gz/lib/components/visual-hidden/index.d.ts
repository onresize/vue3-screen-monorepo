import ElVisuallyHidden from './src/visual-hidden.vue';
export { ElVisuallyHidden };
export default ElVisuallyHidden;
export * from './src/visual-hidden';
