import type { StyleValue } from 'vue';
export declare const visualHiddenProps: {
    readonly style: import("element-plus/es/utils").EpPropFinalized<(new (...args: any[]) => StyleValue & {}) | (() => StyleValue) | ((new (...args: any[]) => StyleValue & {}) | (() => StyleValue))[], unknown, unknown, () => {}, boolean>;
};
