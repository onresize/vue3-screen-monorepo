import 'element-plus/es/components/base/style';
import 'element-plus/es/components/input/style';
import 'element-plus/es/components/button/style';
import 'element-plus/es/components/checkbox/style';
import 'element-plus/es/components/checkbox-group/style';
import 'element-plus/theme-chalk/src/transfer.scss';
