export declare const isKorean: (text: string) => boolean;
