export declare const rAF: (fn: () => void) => number;
export declare const cAF: (handle: number) => void;
