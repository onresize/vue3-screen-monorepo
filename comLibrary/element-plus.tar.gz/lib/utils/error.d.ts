export declare function throwError(scope: string, m: string): never;
export declare function debugWarn(err: Error): void;
export declare function debugWarn(scope: string, message: string): void;
