export declare const getComponentSize: (size?: "" | "default" | "small" | "large" | undefined) => 40 | 32 | 24;
