import { isClient, isIOS } from '@vueuse/core';
export declare const isFirefox: () => boolean;
export { isClient, isIOS };
