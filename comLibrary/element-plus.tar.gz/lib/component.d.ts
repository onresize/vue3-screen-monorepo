import type { Plugin } from 'vue';
declare const _default: Plugin[];
export default _default;
